import io
from PIL import Image
from django.core.files.uploadedfile import InMemoryUploadedFile
image_paths=['/home/sunder/Pictures/sunder.PNG','/home/sunder/Pictures/sunder.PNG']
def imgg(image_Path):
            with open(image_Path, 'rb') as f:
               image_data = f.read()
    
            in_memory_stream = io.BytesIO(image_data)
            image = Image.open(in_memory_stream)
    
            content_type = f'image/{image.format.lower()}'  # Set the content type based on the image format.
            file_name = image_Path.split('/')[-1]
    
            a= InMemoryUploadedFile(
            in_memory_stream,
            field_name=None,    # Set this to the field name of the file if applicable.
            name=file_name,
            content_type=content_type,
            size=len(image_data),
            charset=None,       # Images are binary data, so no charset is needed.
            )
            new=[]
            new.append(a)
            print(type(new))


for image_Path in image_paths:
        ab = imgg(image_Path)
       