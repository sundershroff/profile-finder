from django.urls import path
from profile_finder import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.signin),
    path('signup', views.signup),
    path('statelist/<int:pk>/',views.statelist),
    path('rstatelist/<int:pk>/',views.rstatelist),
    path('fstatelist/<int:pk>/',views.fstatelist),
    path('mstatelist/<int:pk>/',views.mstatelist),
    path('ccstatelist/<int:pk>/',views.ccstatelist),
    path('citylist/<int:pk>/',views.citylist),
    path('rcitylist/<int:pk>/',views.rcitylist),
    path('citylistp/<int:pk>/',views.citylistp),
    path('otp/<id>', views.opt_check),
    path('dashboard/<id>', views.profile_dashboard),
    path('profileidcard/<id>', views.profileidcard),
    path('profileforwhom', views.profileforwhom),
    path('profileform/<id>', views.profileform),
    #path('profilepicture', views.profilepicture),
    path('selfie_upload/<id>',views.selfie_upload),
    path('primary_details/<id>', views.primary_details),
    path('family_details/<id>',views.family_details),
    path('contact_details/<id>',views.contact_details),
    path('header',views.header),
    path('profile_page/<id>',views.profile_page),
    path('menu_header',views.menu_header),
    path('profile_higlight',views.profilehiglight),
    path('payment',views.payment),
    path('matching_list/<id>',views.matching_list),
    path('request_sent/<id>',views.follow_requestsent),
    path('request_received',views.follow_request1),
    path('sucess_story',views.happy_couples),
    path('hai',views.test2),
    #happy Couple
    path('happycouples/<id>', views.happycouple),
    path('uploadyours/', views.uploadyours),
    # path('happycouples1/', views.happycouples1),
    path('happy_couples_test', views.happy_couples_test),
    path('Block', views.block),


]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)