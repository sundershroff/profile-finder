<?php
header('Content-type: text/plain');

$nl = "\n";

//echo('FILES'.' >>>>>>>>>>'.$nl);
print_r($_FILES);
//echo('<<<<<<<<<<<<<<'.$nl.$nl);

//echo('POST DATA'.' >>>>>>>>>>'.$nl);
//print_r($_POST);
//echo('<<<<<<<<<<<<<<'.$nl.$nl);

//echo('REQUEST HEADERS:'.'>>>>>>>>>>'.$nl);
//print_r($_REQUEST);
//echo('<<<<<<<<<<<<<<'.$nl.$nl);
